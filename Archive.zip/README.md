# SG Rental Agent

> Hand-off bundle from the Cowork session of **2026-05-17**.
> Built for Rajul & Poonam's Aug-2026 Singapore rental search.

This folder is everything a Claude CLI session needs to take over the daily rental-listing job — and everything you need to install, run, and tune it on your Mac.

## What this agent does

Every day at **07:00 SGT** the agent:
1. Reads new alert emails from PropertyGuru / 99.co / SRX in a dedicated Gmail inbox
2. Uses Claude to parse each email into structured listings
3. Filters against your hard criteria, enriches with condo metadata, and scores
4. Renders an HTML digest of new matches (top by score; high-priority highlighted)
5. Emails it to Rajul and Poonam
6. Saves the raw data + digest + logs to `…/Housing/House search for Aug 2026/Claude/YYYY-MM-DD/`

## File map

```
sg-rental-agent/
├── README.md                  ← you are here
├── CLAUDE.md                  ← institutional memory; any future Claude reads this first
├── QUICKSTART.md              ← 25-min install
│
├── config/
│   ├── criteria.json          ← hard filters + soft preferences (edit to tune)
│   ├── condos.json            ← 10-condo profiles (commute times, town-gas defaults)
│   └── scoring.json           ← weights for the 0–100 score (edit to re-rank)
│
├── scripts/
│   └── daily_digest.py        ← the runner (IMAP → Claude parse → score → SMTP)
│
├── setup/
│   ├── gmail_setup.md         ← create dedicated Gmail + App Password
│   ├── saved_searches_setup.md← configure portal alerts
│   ├── com.rajul.sg-rental-agent.plist  ← launchd job for 7am daily run
│   └── requirements.txt       ← `pip install -r` (just the anthropic SDK)
│
└── outputs/                   ← agent writes here when run from this dir
    └── .gitkeep
```

## Architecture (in one diagram)

```
PropertyGuru, 99.co, SRX  ──email alerts──▶  rajul.sg.listings@gmail.com
                                                       │
                                                       ▼
              ┌──────────────────────────────────────────────────────────────┐
              │ daily_digest.py (launchd cron, 07:00 daily)                   │
              │                                                                │
              │  1. IMAP fetch last-26h portal emails                          │
              │  2. Claude (Sonnet 4.6) parses each → structured listings      │
              │  3. SQLite dedupe vs ~/.sg-rental-agent/state.db               │
              │  4. Enrich with config/condos.json (MRT walk, school bus,      │
              │     town gas default) → score against config/scoring.json     │
              │  5. Render HTML digest                                          │
              │  6. SMTP send → rajul + poonam                                 │
              │  7. Write /…/Claude/{YYYY-MM-DD}/digest.html, listings.json,   │
              │     run.log                                                     │
              └──────────────────────────────────────────────────────────────┘
                                                       │
                                                       ▼
                       7am inbox · rajul@gmail.com · poonam@…
```

## Why CLI, not Cowork

Cowork's scheduled tasks only fire while the Cowork app is open. A 7am email needs to fire even if the Mac was asleep or Cowork was closed — that's `launchd` (or cron) territory. The dashboard built in Cowork (`../singapore-rental-dashboard.html`) remains useful for the tracker side; the CLI agent feeds it. JSON output is the bridge — the dashboard's import button reads exactly the same shape the CLI writes.

## What's NOT in scope

- **Scraping**: we don't hit portal HTML directly. ToS + anti-bot risk. Saved-search emails are the legitimate, stable feed.
- **Auto-messaging agents**: the digest gives you contact details and an "Open listing" link. Rajul/Poonam decide who to call.
- **Account/credit checks for the lease**: out of scope for this agent.

## Where to look first when something breaks

- **Empty digests every morning** → saved-search alerts aren't flowing. Open the dedicated Gmail and check whether any portal emails are arriving. Re-run `setup/saved_searches_setup.md`.
- **Agent stops running** → `launchctl list | grep sg-rental` should show it's loaded. Tail `~/Library/Logs/sg-rental-agent.err.log`.
- **Claude parse errors** → check `outputs/{today}/run.log`. Most often the portal changed its email HTML; tune the parse prompt in `scripts/daily_digest.py:parse_listings_with_claude`.

## Sibling artefacts in this same day's folder

`../singapore-rental-dashboard.html` — the interactive Cowork dashboard (open in any browser).
`../sg-rental-shortlist.pdf` — clean printable shortlist for Poonam.
