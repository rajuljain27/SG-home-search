# Quickstart — get the 7am digest running

Total time: **~25 minutes** of which only **~5 minutes** is hands-on. The rest is waiting for portal alerts to start arriving.

## 0. Prereqs check (1 min)

```bash
python3 --version    # need 3.10+
which python3
```

## 1. Put this folder in your Housing directory (1 min)

Move the whole `sg-rental-agent/` folder under your existing Housing tree:

```
/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/2026-05-17/sg-rental-agent/
```

(That's already where it's sitting if you opened this from there.)

## 2. Install the one Python dependency (1 min)

```bash
pip3 install --user anthropic
# or in a venv:
python3 -m venv ~/.sg-rental-agent/venv
~/.sg-rental-agent/venv/bin/pip install anthropic
```

## 3. Gmail (10 min) → see `setup/gmail_setup.md`

- Create `rajul.sg.listings@gmail.com`
- Turn on 2-Step Verification
- Generate App Password
- Drop secrets into `~/.sg-rental-agent/.env`

## 4. Saved searches (10 min) → see `setup/saved_searches_setup.md`

- PropertyGuru: District 16, 3BR, ≤S$6k, ≥1,350 sqft → Save → Email instant alerts
- 99.co: same filters → Bell icon → alerts
- SRX: same filters → Daily digest

## 5. Smoke test (1 min)

```bash
set -a; source ~/.sg-rental-agent/.env; set +a
cd "/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/2026-05-17/sg-rental-agent"
python3 scripts/daily_digest.py --dry-run
```

A successful dry-run will:
- Log `Fetched N portal emails in last 26h` (N can be 0 on day-1)
- Write `outputs/{today}/listings.json` and `digest.html`
- NOT send email and NOT mark URLs as seen

Open `digest.html` in your browser to preview what tomorrow's email will look like.

## 6. Schedule the 7am job (2 min) → `setup/com.rajul.sg-rental-agent.plist`

```bash
cp setup/com.rajul.sg-rental-agent.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.rajul.sg-rental-agent.plist
```

Test it fires:

```bash
launchctl kickstart -k gui/$(id -u)/com.rajul.sg-rental-agent
tail -f ~/Library/Logs/sg-rental-agent.out.log
```

## You're done.

Tomorrow at 7am, you and Poonam get the first real digest.

## Common operations

### Tune what shows up
Edit `config/criteria.json` (rent ceiling, size floor, etc.) or `config/scoring.json` (weights). No code change needed.

### Add a new condo to the shortlist
Append an entry to `config/condos.json`. The agent picks it up on the next run.

### Reset the "seen" state (force re-surface)
```bash
rm ~/.sg-rental-agent/state.db
```

### Disable the job temporarily (travel etc.)
```bash
launchctl unload ~/Library/LaunchAgents/com.rajul.sg-rental-agent.plist
```
Re-enable with `load`.

### Audit yesterday's run
```bash
open "/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/$(date -v-1d +%Y-%m-%d)/"
```
You'll see `digest.html`, `listings.json`, `run.log`.

### When something goes wrong
The agent emails Rajul with a stacktrace if a run blows up. Check `~/Library/Logs/sg-rental-agent.err.log` for the detail.
