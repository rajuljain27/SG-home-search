#!/usr/bin/env python3
"""
daily_digest.py — SG Rental Agent main runner.

Reads new listing alert emails from a dedicated Gmail inbox, asks Claude to
parse them into structured listings, scores them against the criteria,
renders an HTML digest, and emails it to Rajul + Poonam at 7am.

Designed to be invoked by launchd at 07:00 local time daily.

Environment variables (load from ~/.sg-rental-agent/.env):
  ANTHROPIC_API_KEY      Claude API key
  GMAIL_ADDRESS          rajul.sg.listings@gmail.com
  GMAIL_APP_PASSWORD     16-char App Password (NOT your account password)
  TO_RAJUL               rajuljain@gmail.com
  TO_POONAM              poonam@example.com           (fill in)
  OUTPUT_ROOT            /Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude
  STATE_DB               ~/.sg-rental-agent/state.db
  CONFIG_DIR             /path/to/sg-rental-agent/config

Exit codes:
  0  success (even if 0 new listings — we still send the run-status email)
  1  configuration error (missing env, missing config)
  2  Gmail auth or fetch error
  3  Claude API error
  4  Send-mail error
"""
from __future__ import annotations

import argparse
import datetime as dt
import email
import imaplib
import json
import logging
import os
import pathlib
import smtplib
import sqlite3
import ssl
import sys
import traceback
from email.message import EmailMessage
from email.utils import parsedate_to_datetime
from html import escape
from typing import Any

# --- 0. paths & env --------------------------------------------------------

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_CONFIG_DIR = ROOT / "config"

def env(key: str, default: str | None = None, *, required: bool = False) -> str:
    val = os.environ.get(key, default)
    if required and not val:
        sys.stderr.write(f"FATAL: env var {key} is required.\n")
        sys.exit(1)
    return val or ""

ANTHROPIC_API_KEY = env("ANTHROPIC_API_KEY", required=True)
GMAIL_ADDRESS     = env("GMAIL_ADDRESS",     required=True)
GMAIL_APP_PASS    = env("GMAIL_APP_PASSWORD", required=True)
TO_RAJUL          = env("TO_RAJUL",          required=True)
TO_POONAM         = env("TO_POONAM", "")
OUTPUT_ROOT       = pathlib.Path(env("OUTPUT_ROOT",
    str(pathlib.Path.home() / "Desktop/Rajul/Housing/House search for Aug 2026/Claude")))
STATE_DB          = pathlib.Path(env("STATE_DB",
    str(pathlib.Path.home() / ".sg-rental-agent/state.db")))
CONFIG_DIR        = pathlib.Path(env("CONFIG_DIR", str(DEFAULT_CONFIG_DIR)))

TODAY     = dt.date.today()
TODAY_STR = TODAY.isoformat()
DAY_DIR   = OUTPUT_ROOT / TODAY_STR
DAY_DIR.mkdir(parents=True, exist_ok=True)
STATE_DB.parent.mkdir(parents=True, exist_ok=True)

# --- logging ---------------------------------------------------------------

LOG_PATH = DAY_DIR / "run.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("sg-rental-agent")

# --- config loaders --------------------------------------------------------

def load_json(name: str) -> dict[str, Any]:
    path = CONFIG_DIR / name
    if not path.exists():
        log.error("Missing config file %s", path)
        sys.exit(1)
    with path.open() as f:
        return json.load(f)

CRITERIA = load_json("criteria.json")
CONDOS   = load_json("condos.json")
SCORING  = load_json("scoring.json")

# --- state db --------------------------------------------------------------

def init_db() -> sqlite3.Connection:
    conn = sqlite3.connect(STATE_DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS seen_listings (
          url        TEXT PRIMARY KEY,
          first_seen TEXT NOT NULL,
          source     TEXT,
          condo      TEXT,
          rent_sgd   INTEGER,
          score      INTEGER,
          raw_json   TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS runs (
          run_date  TEXT PRIMARY KEY,
          emails    INTEGER,
          listings  INTEGER,
          new_count INTEGER,
          surfaced  INTEGER,
          ok        INTEGER
        )
    """)
    return conn

# --- 1. fetch portal alert emails from Gmail -------------------------------

PORTAL_SENDERS = ["propertyguru.com.sg", "99.co", "srx.com.sg", "edgeprop.sg"]

def fetch_recent_emails(hours: int = 26) -> list[dict[str, Any]]:
    log.info("Connecting to Gmail IMAP as %s", GMAIL_ADDRESS)
    try:
        M = imaplib.IMAP4_SSL("imap.gmail.com", 993)
        M.login(GMAIL_ADDRESS, GMAIL_APP_PASS)
        M.select("INBOX")
    except imaplib.IMAP4.error as e:
        log.error("Gmail auth failed: %s", e)
        sys.exit(2)

    cutoff = (dt.datetime.now() - dt.timedelta(hours=hours))
    since  = cutoff.strftime("%d-%b-%Y")
    emails: list[dict[str, Any]] = []

    for domain in PORTAL_SENDERS:
        # IMAP SEARCH: emails since cutoff date from this domain
        # We over-fetch by date (day-granularity) and filter precisely below.
        typ, data = M.search(None, f'(SINCE "{since}" FROM "{domain}")')
        if typ != "OK":
            log.warning("IMAP search failed for %s", domain)
            continue
        for num in data[0].split():
            typ, msg_data = M.fetch(num, "(RFC822)")
            if typ != "OK":
                continue
            msg = email.message_from_bytes(msg_data[0][1])
            try:
                received = parsedate_to_datetime(msg["Date"])
                if received < cutoff:
                    continue
            except Exception:
                pass
            body = _extract_body(msg)
            emails.append({
                "from": msg.get("From", ""),
                "subject": msg.get("Subject", ""),
                "date": msg.get("Date", ""),
                "domain": domain,
                "body_html": body.get("html", ""),
                "body_text": body.get("text", ""),
            })

    try: M.close()
    except: pass
    try: M.logout()
    except: pass
    log.info("Fetched %d portal emails in last %dh", len(emails), hours)
    return emails


def _extract_body(msg: email.message.Message) -> dict[str, str]:
    out = {"text": "", "html": ""}
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            if part.get("Content-Disposition") and "attach" in part.get("Content-Disposition", ""):
                continue
            payload = part.get_payload(decode=True) or b""
            try: text = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
            except Exception: text = payload.decode("utf-8", errors="replace")
            if ctype == "text/plain" and not out["text"]:
                out["text"] = text
            elif ctype == "text/html" and not out["html"]:
                out["html"] = text
    else:
        payload = msg.get_payload(decode=True) or b""
        text = payload.decode(msg.get_content_charset() or "utf-8", errors="replace")
        if msg.get_content_type() == "text/html":
            out["html"] = text
        else:
            out["text"] = text
    return out

# --- 2. Claude parses each email into structured listings ------------------

def parse_listings_with_claude(emails: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Call Claude once per email; ask it to extract structured listings."""
    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    all_listings: list[dict[str, Any]] = []

    schema_prompt = """You are extracting Singapore rental property listings from a portal email.
Return ONLY a JSON array (no prose, no markdown fence) with objects shaped like:
{
  "url": string,               // full https URL to the listing page
  "condo": string,             // condo / development name as written
  "rent_sgd": number|null,     // monthly rent in SGD, integer
  "size_sqft": number|null,
  "bedrooms": number|null,
  "bathrooms": number|null,
  "listed_date": string|null,  // ISO date if visible
  "agent_name": string|null,
  "agent_phone": string|null,
  "furnishing": string|null,   // "unfurnished" | "partial" | "fully furnished" | null
  "raw_snippet": string        // first ~200 chars of the listing description as it appears
}
If the email has 0 listings (e.g. it's a marketing newsletter), return []."""

    for em in emails:
        body = em["body_text"] or em["body_html"]
        if len(body) > 80_000:
            body = body[:80_000]
        try:
            resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=4000,
                system=schema_prompt,
                messages=[{
                    "role": "user",
                    "content": (
                        f"Sender: {em['from']}\n"
                        f"Subject: {em['subject']}\n"
                        f"Date: {em['date']}\n\n"
                        f"--- BODY ---\n{body}"
                    ),
                }],
            )
            text = resp.content[0].text.strip()
            # Strip code fences if Claude added them anyway
            if text.startswith("```"):
                text = text.split("```", 2)[1].lstrip("json\n").rstrip("`").strip()
            listings = json.loads(text)
            for l in listings:
                l["_source_domain"] = em["domain"]
                l["_source_subject"] = em["subject"]
            all_listings.extend(listings)
            log.info("Parsed %d listings from %s", len(listings), em["domain"])
        except json.JSONDecodeError as e:
            log.warning("JSON parse failed for email from %s: %s", em["domain"], e)
        except Exception as e:
            log.error("Claude error on email from %s: %s", em["domain"], e)
            log.debug(traceback.format_exc())
    return all_listings

# --- 3. enrich, dedupe, filter, score --------------------------------------

def find_condo(name: str | None) -> dict[str, Any] | None:
    if not name:
        return None
    needle = name.strip().lower()
    for c in CONDOS["condos"]:
        candidates = [c["name"].lower()] + [a.lower() for a in c.get("aliases", [])]
        if any(needle == cand or needle in cand or cand in needle for cand in candidates):
            return c
    return None


def passes_hard_filters(l: dict[str, Any], condo: dict[str, Any] | None) -> tuple[bool, list[str]]:
    hf = CRITERIA["hard_filters"]
    fails = []
    if l.get("rent_sgd") is None or l["rent_sgd"] > hf["max_rent_sgd"]:
        if l.get("rent_sgd") is not None:
            fails.append(f"rent S${l['rent_sgd']} > S${hf['max_rent_sgd']}")
    if l.get("size_sqft") is None or l["size_sqft"] < hf["min_size_sqft"]:
        if l.get("size_sqft") is not None:
            fails.append(f"size {l['size_sqft']} sqft < {hf['min_size_sqft']}")
    if l.get("bedrooms") is not None and l["bedrooms"] < hf["min_bedrooms"]:
        fails.append(f"{l['bedrooms']} BR < {hf['min_bedrooms']}")
    if condo and condo.get("rajul_mrt_walk_min", 99) > hf["rajul_mrt_walk_max_min"] and condo["tier"] != "C":
        # Note: we still surface Tier-C listings if every other criterion is met
        pass
    return (len(fails) == 0, fails)


def score_listing(l: dict[str, Any], condo: dict[str, Any] | None) -> tuple[int, dict[str, int]]:
    s: dict[str, int] = {}
    rent = l.get("rent_sgd")
    size = l.get("size_sqft")

    # Rent
    s["rent"] = 0
    if rent is not None:
        for t in SCORING["buckets"]["rent"]["tiers"]:
            if rent <= t["if_max_sgd"]:
                s["rent"] = t["score"]; break

    # Size
    s["size"] = 0
    if size is not None:
        for t in SCORING["buckets"]["size"]["tiers"]:
            if size >= t["if_min_sqft"]:
                s["size"] = t["score"]; break

    # MRT walk (use condo metadata)
    s["rajul_mrt_walk"] = 0
    if condo:
        w = condo.get("rajul_mrt_walk_min", 99)
        for t in SCORING["buckets"]["rajul_mrt_walk"]["tiers"]:
            if w <= t["if_max_min"]:
                s["rajul_mrt_walk"] = t["score"]; break

    # School commute (use condo metadata)
    s["aadya_school_commute"] = 0
    if condo:
        sc = condo.get("aadya_school_bus_min", 99)
        for t in SCORING["buckets"]["aadya_school_commute"]["tiers"]:
            if sc <= t["if_max_min"]:
                s["aadya_school_commute"] = t["score"]; break

    # Town gas (condo default — listing-specific verification still needed)
    s["town_gas"] = SCORING["buckets"]["town_gas"]["if_present"] if condo and condo.get("town_gas_default") == "yes" else 0

    # Furnishing
    s["unfurnished_or_partial"] = 0
    f = (l.get("furnishing") or "").lower()
    if "unfurn" in f or "partial" in f:
        s["unfurnished_or_partial"] = SCORING["buckets"]["unfurnished_or_partial"]["if_present"]

    # Listing-specific features not knowable from email parse — default 0; user marks in dashboard.
    # We leave 'aircon', 'view_water_or_reservoir', 'balcony', 'ceiling_fans', 'helper_room' as 0 here.
    # (Email parse rarely reveals these reliably; the dashboard scoring fills them in once user inspects.)
    s["helper_room"] = 0
    s["aircon"] = 0
    s["view_water_or_reservoir"] = 0
    s["balcony"] = 0
    s["ceiling_fans"] = 0

    return sum(s.values()), s


def dedupe(conn: sqlite3.Connection, listings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    new: list[dict[str, Any]] = []
    for l in listings:
        url = (l.get("url") or "").strip()
        if not url:
            continue
        row = conn.execute("SELECT 1 FROM seen_listings WHERE url = ?", (url,)).fetchone()
        if row:
            continue
        new.append(l)
    return new


def persist_seen(conn: sqlite3.Connection, listings: list[dict[str, Any]]) -> None:
    for l in listings:
        conn.execute("""
            INSERT OR IGNORE INTO seen_listings
                (url, first_seen, source, condo, rent_sgd, score, raw_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            l["url"], TODAY_STR, l.get("_source_domain", ""),
            l.get("condo", ""), l.get("rent_sgd"),
            l.get("_score", 0), json.dumps(l, default=str)
        ))
    conn.commit()

# --- 4. render HTML digest -------------------------------------------------

def render_digest(listings: list[dict[str, Any]], stats: dict[str, int]) -> str:
    surface_min = SCORING["thresholds"]["surface_in_digest_min_score"]
    high_min    = SCORING["thresholds"]["high_priority_min_score"]

    listings = sorted(listings, key=lambda x: -x.get("_score", 0))
    surfaced = [l for l in listings if l.get("_score", 0) >= surface_min]

    cards = []
    for l in surfaced:
        score   = l.get("_score", 0)
        is_hi   = score >= high_min
        condo   = l.get("_condo_meta") or {}
        breakdown = l.get("_score_breakdown") or {}
        b_html = " · ".join(f"{k}:{v}" for k, v in breakdown.items() if v)
        cards.append(f"""
          <div style="border:1px solid #e5e7eb; border-radius:10px; padding:14px 16px; margin-bottom:12px;
                      background:{'#fef9e7' if is_hi else '#fff'};">
            <div style="display:flex; justify-content:space-between; gap:10px;">
              <div>
                <div style="font-weight:700; color:#0f172a; font-size:15px;">
                  {escape(l.get('condo') or '—')}
                  {f'<span style="background:#15803d;color:#fff;padding:2px 7px;border-radius:99px;font-size:11px;margin-left:6px;">HIGH</span>' if is_hi else ''}
                </div>
                <div style="color:#64748b; font-size:13px; margin-top:2px;">
                  {escape(str(l.get('size_sqft') or '?'))} sqft ·
                  {escape(str(l.get('bedrooms') or '?'))}BR/{escape(str(l.get('bathrooms') or '?'))}BA ·
                  S${escape(str(l.get('rent_sgd') or '?'))}/mo ·
                  {escape(l.get('furnishing') or 'furnishing ?')}
                </div>
              </div>
              <div style="font-size:22px; font-weight:700; color:#0f172a;
                          background:#f1f5f9; padding:4px 10px; border-radius:8px;">
                {score}
              </div>
            </div>
            <div style="color:#475569; font-size:12px; margin-top:6px;">
              Rajul→MRT: {escape(str(condo.get('rajul_mrt_walk_min','?')))} min ·
              Aadya→UWC: ~{escape(str(condo.get('aadya_school_bus_min','?')))} min bus ·
              Town gas (default): {escape(str(condo.get('town_gas_default','?')))}
            </div>
            <div style="color:#475569; font-size:11px; margin-top:4px;">{escape(b_html)}</div>
            <div style="margin-top:8px;">
              <a href="{escape(l.get('url') or '#')}" style="color:#1d4ed8;">Open listing →</a>
              {f' &nbsp; · &nbsp; <a href="tel:{escape(l.get("agent_phone") or "")}" style="color:#1d4ed8;">Call {escape(l.get("agent_name") or "agent")}</a>' if l.get("agent_phone") else ''}
            </div>
            <div style="color:#94a3b8; font-size:11px; margin-top:4px;">via {escape(l.get('_source_domain',''))}</div>
          </div>
        """)

    body = f"""<!DOCTYPE html>
<html><body style="font-family:-apple-system,BlinkMacSystemFont,sans-serif; color:#1f2937; max-width:680px; margin:0 auto; padding:20px;">
  <h2 style="color:#0f172a; margin:0 0 4px;">🏠 SG Rentals — {TODAY_STR}</h2>
  <div style="color:#64748b; font-size:13px; margin-bottom:14px;">
    {stats['surfaced']} match{'es' if stats['surfaced']!=1 else ''} · {stats['new']} new listings parsed · {stats['emails']} portal emails
  </div>
  {''.join(cards) if cards else '<div style="padding:18px; border:2px dashed #e5e7eb; border-radius:10px; text-align:center; color:#64748b;">No new matches passed the criteria today. Sources checked: PropertyGuru · 99.co · SRX.</div>'}
  <hr style="border:none; border-top:1px solid #e5e7eb; margin:24px 0 12px;">
  <div style="color:#94a3b8; font-size:11px;">
    Singapore Rental Agent · automated digest · sent {TODAY_STR} 07:00 SGT<br>
    Sources: PropertyGuru, 99.co, SRX (saved-search alert emails).<br>
    Adjust criteria in <code>config/criteria.json</code>; reranks in <code>config/scoring.json</code>.
  </div>
</body></html>"""
    return body

# --- 5. send email ---------------------------------------------------------

def send_email(html_body: str, subject: str, recipients: list[str]) -> None:
    msg = EmailMessage()
    msg["From"] = GMAIL_ADDRESS
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content("HTML view required. Open this email in a modern client.")
    msg.add_alternative(html_body, subtype="html")

    ctx = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ctx) as s:
            s.login(GMAIL_ADDRESS, GMAIL_APP_PASS)
            s.send_message(msg)
        log.info("Sent digest to %s", recipients)
    except Exception as e:
        log.error("SMTP send failed: %s", e)
        sys.exit(4)

# --- main ------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="Parse and render, but don't send email or persist state")
    ap.add_argument("--hours", type=int, default=26)
    args = ap.parse_args()

    log.info("Run starting · day=%s · output=%s", TODAY_STR, DAY_DIR)
    conn = init_db()

    try:
        emails = fetch_recent_emails(hours=args.hours)
        parsed = parse_listings_with_claude(emails)
        new    = dedupe(conn, parsed)

        # enrich + score
        for l in new:
            condo = find_condo(l.get("condo"))
            l["_condo_meta"] = condo or {}
            ok, fails = passes_hard_filters(l, condo)
            l["_passes_hard"] = ok
            l["_hard_fails"] = fails
            score, breakdown = score_listing(l, condo)
            l["_score"] = score
            l["_score_breakdown"] = breakdown

        surface_min = SCORING["thresholds"]["surface_in_digest_min_score"]
        surfaced = [l for l in new if l.get("_passes_hard") and l["_score"] >= surface_min]

        stats = {"emails": len(emails), "new": len(new), "surfaced": len(surfaced)}
        log.info("Stats: %s", stats)

        # Write daily artefacts
        (DAY_DIR / "listings.json").write_text(json.dumps(new, indent=2, default=str))
        digest = render_digest(new, stats)
        (DAY_DIR / "digest.html").write_text(digest)

        if not args.dry_run:
            recipients = [TO_RAJUL] + ([TO_POONAM] if TO_POONAM else [])
            subj = f"🏠 SG Rentals · {stats['surfaced']} new match{'es' if stats['surfaced']!=1 else ''} · {TODAY_STR}"
            send_email(digest, subj, recipients)
            persist_seen(conn, new)

        conn.execute("""INSERT OR REPLACE INTO runs(run_date, emails, listings, new_count, surfaced, ok)
                        VALUES (?, ?, ?, ?, ?, 1)""",
                     (TODAY_STR, stats["emails"], len(parsed), stats["new"], stats["surfaced"]))
        conn.commit()

    except SystemExit:
        raise
    except Exception:
        log.exception("Unhandled error")
        try:
            err_html = f"<pre>{escape(traceback.format_exc())}</pre>"
            send_email(err_html, f"⚠️ SG Rentals · run failed · {TODAY_STR}", [TO_RAJUL])
        except Exception:
            pass
        sys.exit(5)
    finally:
        conn.close()

    log.info("Run complete · day=%s", TODAY_STR)


if __name__ == "__main__":
    main()
