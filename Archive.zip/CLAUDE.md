# SG Rental Agent — Institutional Memory

**Owner:** Rajul Jain (rajuljain@gmail.com) & Poonam Jain
**Mission:** Surface new Singapore rental listings that match our criteria every morning at 7am.
**Status:** v1 — Cowork dashboard built; daily-digest CLI agent under setup.
**Last updated:** 2026-05-17 by the previous Claude (Cowork session).

> **If you're a future Claude reading this:** Read this file end-to-end before touching anything. It carries the full history of decisions we've already made so we don't relitigate them. If the user asks a question that's already settled here, surface what we decided and *why*, then offer to revise if circumstances have changed.

---

## 1. Family & timeline

- **Rajul** — 46, British citizen, Indian ethnicity. Recently re-rotated to Singapore (second stint here; previously Australia, then India). Works at Visa, office at **71 Robinson Road**.
- **Poonam** — 46, Rajul's wife. Currently in India, joining Rajul in Singapore.
- **Aadya** — 11 years old, daughter. Currently in India.
- **Move-in target:** **1 August 2026**.
- **Lease term:** 2 years.
- **Background:** Shipping household goods from Mumbai — beds, dining table, fridge, microwave, etc. So **unfurnished or partially furnished is strongly preferred**.

## 2. Hard criteria (a listing must satisfy all of these)

| # | Criterion | Why |
|---|-----------|-----|
| 1 | Rent ≤ **S$6,000/month** | Budget ceiling — prefer lower |
| 2 | **3 bedrooms + 2 bathrooms** minimum | Family size |
| 3 | **Helper's room with attached W/C** | Household includes a domestic helper |
| 4 | **≥ 1,350 sqft** | Below this, the helper's room is usually a converted store |
| 5 | **Rajul's MRT walk ≤ 8 min** on DTL (blue), EWL (green), or TEL (brown) | Office commute (Telok Ayer / Raffles / Tanjong Pagar / Shenton Way) |
| 6 | **Aadya's school commute** by school bus or *single direct bus* — **no MRT+bus transfer**, ≤ 40 min door-to-door | UWC East (1 Tampines St 73). UWC has no nearby MRT, so school bus is the realistic option from every condo we shortlist. |

## 3. Soft preferences (used for scoring, not filtering)

- **Piped town gas** stove (Mumbai cook prefers gas over induction)
- **Aircon** included (don't want to buy)
- **Ceiling fans** in living + bedrooms
- **Curtains/blinds** included
- **Washing machine** included
- **Balcony**
- **Reservoir or water view**
- **Adequate plug points** (will plug in lots of appliances + Indian charger setups)

## 4. Geographic shortlist — 10 condos

Stored as data in `config/condos.json`. Three tiers:

- **Tier A (strong fit, start here):** The Clearwater, Aquarius by the Park
- **Tier B (borderline on MRT walk or rent):** Baywater, Waterfront Waves, Waterfront Isle, Waterfront Key, Waterfront Gold, Costa Del Sol
- **Tier C (fails MRT walk for Rajul):** The Tropica, Tropical Spring — only consider if a unit hits every soft preference and rent is at the bottom of range.

**Costa Del Sol is the dark horse:** Bayshore TEL (~8 min) + Tanah Merah EWL (~10 min) within walking range — two-line advantage for Rajul's office commute, geographically closest condo to UWC East on the list. The catch is rent (S$5.5k+ typically).

If a listing in a condo *not* on this shortlist appears and meets all hard criteria, surface it as a "new candidate" — don't suppress it. We may have missed inventory.

## 5. Scoring algorithm (0–100)

Stored as weights in `config/scoring.json`. Used to rank listings for the morning digest.

| Bucket | Max | Logic |
|--------|-----|-------|
| Rent | 25 | ≤5000: 25 · ≤5500: 20 · ≤6000: 12 · ≤6500: 4 · else 0 |
| Size | 15 | ≥1350: 15 · ≥1250: 8 · else 0 |
| Helper's room (with WC) | 15 | binary |
| Rajul's MRT walk | 10 | ≤5min: 10 · ≤8min: 8 · ≤12min: 4 · else 0 |
| Aadya's school commute | 10 | ≤25min: 10 · ≤30min: 8 · ≤35min: 5 · ≤40min: 2 · else 0 |
| Town gas | 5 | binary |
| AC included | 5 | binary |
| Reservoir/water view | 5 | binary |
| Unfurnished/partial | 4 | binary |
| Balcony | 3 | binary |
| Ceiling fans | 3 | binary |

**Surface in the digest:** any listing scoring ≥ 55. Highlight ≥ 75 as "high priority". Below 40, suppress unless it's the only thing today.

## 6. Data sources & how to read them

### 6.1 Saved-search portal emails (PRIMARY — official, real-time)

We've configured saved-search alerts on the three main Singapore rental portals. Each portal emails new matching listings as they're posted. **These emails are the agent's gold-standard input.**

| Portal | Sender domain | Typical email format |
|--------|---------------|----------------------|
| PropertyGuru | @propertyguru.com.sg | Subject contains "saved search" or "new listing"; body lists 1+ listings with URL, condo, rent, bedrooms, size. |
| 99.co | @99.co | Similar — list of cards, URLs prefixed `https://www.99.co/singapore/...` |
| SRX | @srx.com.sg | Daily digest, plainer HTML |

User forwards portal emails to a dedicated inbox: **`rajul.sg.listings@gmail.com`** (to be created — see `setup/gmail_setup.md`).

### 6.2 WebSearch supplement (secondary)

Google's index of PropertyGuru / 99.co / SRX listings catches some inventory that doesn't trigger the portal alerts (different keyword matches). The agent can run a single morning WebSearch as a belt-and-braces second pass:

> `"Bedok Reservoir" OR "Bayshore" 3 bedroom condo rent 2026 helper "S$5" OR "S$6"`

Listings already seen (by URL) should be deduped via the SQLite state DB.

### 6.3 What NOT to do

- **Do not** scrape PropertyGuru / 99.co / SRX directly. Their ToS prohibits it, anti-bot defences will break the agent within weeks, and IP bans risk the user's home IP. The saved-search emails are the only stable, legal feed.
- **Do not** auto-message agents on the user's behalf. Surface the listing; let Rajul/Poonam decide whom to contact.

## 7. Daily workflow (what the agent does at 7am)

```
1. Open Gmail inbox (rajul.sg.listings@gmail.com) via IMAP.
2. Fetch all emails received in the last 26 hours from {propertyguru.com.sg, 99.co, srx.com.sg}.
3. For each email, call the Anthropic API (Claude Sonnet 4.6) with the email HTML
   and a JSON-schema prompt to extract structured listings:
     [{url, condo, rent_sgd, size_sqft, bedrooms, bathrooms,
       listed_date, agent_name, agent_phone, posting_source}]
4. Dedupe new listings against ~/.sg-rental-agent/state.db (key = url).
5. For each new listing, enrich with condo metadata from config/condos.json
   (MRT walk minutes, town gas typical-default, school-bus time, tier).
6. Apply hard filters (rent / size / beds / district).
7. Apply scoring algorithm.
8. Optionally run one WebSearch pass for additional listings (steps 4–7 again).
9. Render an HTML digest (top-by-score; cards with score breakdown, "Open listing" + mailto: to agent).
10. Send via Gmail SMTP from rajul.sg.listings@gmail.com to rajul + poonam.
11. Save outputs to:
       /Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/{YYYY-MM-DD}/
         digest.html         — the email body
         listings.json       — raw + scored data
         run.log             — timestamps, counts, errors
12. Mark all parsed URLs as "seen" in state.db.
```

If **zero** new listings: still send a one-line email so the user knows the job ran ("0 new matches today — sources checked: PG, 99, SRX"). Silence is worse than zero.

If a step **fails** (Gmail auth, API down): send an error email to Rajul; log full stacktrace; do not silently skip.

## 8. Output organization

All outputs — Cowork sessions and CLI agent runs — live in:

```
/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/
├── 2026-05-16/                                    ← yesterday's first Cowork build
│   └── (initial dashboard + PDF)
├── 2026-05-17/                                    ← today
│   ├── singapore-rental-dashboard.html            ← interactive tracker
│   ├── sg-rental-shortlist.pdf                    ← clean PDF for Poonam
│   └── sg-rental-agent/                           ← THIS PACKAGE
└── 2026-05-18/                                    ← first auto-run
    ├── digest.html
    ├── listings.json
    └── run.log
```

## 9. Live action items (carry forward across sessions)

- [ ] **Rajul:** create `rajul.sg.listings@gmail.com`, generate Gmail App Password (see `setup/gmail_setup.md`).
- [ ] **Rajul:** set up saved-search alerts on PropertyGuru, 99.co, SRX, forward all alert mail to `rajul.sg.listings@gmail.com` (see `setup/saved_searches_setup.md`).
- [ ] **Rajul:** drop the Anthropic API key into `~/.sg-rental-agent/.env` (`ANTHROPIC_API_KEY=...`).
- [ ] **Rajul:** load the launchd plist (see `setup/com.rajul.sg-rental-agent.plist`).
- [ ] **Rajul (school):** email `uwcseaeast@uwcsea.edu.sg` with the shortlist asking which condos are on existing school-bus routes for 2026–27. This single answer should drive the final pick.
- [ ] **Agent (each morning):** check state.db hasn't been corrupted; log success/failure.

## 10. Open questions / known unknowns

- **UWCSEA bus routes for 2026–27** are not finalised at the time of this writing. Update tier rankings if a condo turns out to be off-route.
- **Town gas** flags in `condos.json` are typical-defaults at the development level — *every individual unit can have been converted to induction*. Always cross-check the actual listing description, and verify in person at viewing.
- **Furnishing** distinctions on listings are inconsistent ("partially furnished" varies wildly). Surface whatever the listing says; let humans interpret.
- **Costa Del Sol** specifically: rents are creeping up post-2024 east-side gentrification. If we see consistent listings >S$6.5k, drop it from the shortlist.

## 11. How to evolve this file

When new information surfaces — a condo we missed, a viewing tells us something the listing didn't (e.g. "Aquarius blocks 11–15 have noisy lift motors"), a UWC bus route confirmation — **append to the relevant section above**, with a date stamp.

Do **not** rewrite history. The audit trail is the value. Future Claudes need to see that we considered something and rejected it, not just the current consensus.

## 12. Pointers to related files

- `config/criteria.json` — hard + soft criteria as data
- `config/condos.json` — 10-condo profiles (all data shown in §4 above)
- `config/scoring.json` — scoring weights
- `scripts/daily_digest.py` — the runner
- `scripts/parse_listings.py` — Claude-powered email parser
- `scripts/send_email.py` — SMTP sender
- `setup/gmail_setup.md` — App Password setup (one-time)
- `setup/saved_searches_setup.md` — portal alerts setup (one-time)
- `setup/com.rajul.sg-rental-agent.plist` — 7am cron via launchd
- `QUICKSTART.md` — 10-minute install
- `../singapore-rental-dashboard.html` — the long-term tracker dashboard (Cowork artifact, run locally too)
- `../sg-rental-shortlist.pdf` — printable shortlist for Poonam
