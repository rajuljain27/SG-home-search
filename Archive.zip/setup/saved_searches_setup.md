# Saved-search alerts setup — one-time, ~15 minutes

The agent reads its input from the portals' own alert emails. Set these up once and you're done.

## PropertyGuru

1. Sign in to <https://www.propertyguru.com.sg> using **rajul.sg.listings@gmail.com** (not your personal Gmail — keeps alerts isolated).
2. Apply this set of filters in the rent search:
   - Property type: **Condominium**
   - Listing type: **For Rent**
   - **District 16**
   - Beds: **3**
   - Min size: **1,350 sqft**
   - Max price: **S$6,000**
   - Furnishing: **Unfurnished** + **Partially Furnished**
3. Click **Save search** above the results.
4. Toggle **Email me new listings → Instant** (or Daily if Instant isn't available).

Repeat once more for the Bayshore / Costa Del Sol angle:
   - **District 16**, near **Bayshore MRT**, 3 BR, max S$6,500, min 1,300 sqft.

## 99.co

1. Sign in to <https://www.99.co> with the same dedicated email.
2. Filter:
   - **For Rent**, **Condo**, **District 16**
   - Beds **3**
   - Max price **S$6,000**
   - Sidebar slider **Walking distance to MRT ≤ 8 min**
   - Furnishing **Unfurnished / Partially Furnished**
3. Click the **bell icon** at the top of results → confirm email alerts.

Optional second saved search keyed to a specific condo, e.g.:
   - Search box: `Costa Del Sol` → Save → alerts.

## SRX

1. Sign in to <https://www.srx.com.sg>.
2. Filter:
   - Condo, **For Rent**, **District 16**, 3 BR, max S$6,000, min 1,350 sqft.
3. **Save search** → choose **Daily digest**.

## EdgeProp (optional)

EdgeProp is best for historical transaction data. Skip the alerts unless you want a fourth firehose.

## Confirm alerts are flowing

Within 24 hours of saving, you should get at least one email from each portal at **rajul.sg.listings@gmail.com**. If you haven't seen anything from a portal after 48h:

- Check Spam / Promotions tab.
- Make sure the saved search includes broad enough filters to actually match something today (try widening to S$7k for a day to confirm the pipeline works, then narrow back).
- Re-check the email address on your portal account — typo in setup is the #1 cause.

## Move alerts out of Promotions tab

Gmail tends to dump portal alerts into the *Promotions* category, which IMAP search can still see — but you don't want them buried.

In Gmail, **Settings → Filters and Blocked Addresses → Create new filter**:
- From: `propertyguru.com.sg`
- → **Skip Inbox? No · Never send to Spam · Apply label: portal-alerts · Categorize as: Primary**

Repeat for `99.co` and `srx.com.sg`.

## You're done. Hand off to the agent.

The next step is to drop the launchd plist in place — see `setup/com.rajul.sg-rental-agent.plist`.
