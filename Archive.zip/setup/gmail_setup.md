# Gmail setup — one-time, ~10 minutes

## Why a dedicated inbox

PropertyGuru / 99.co / SRX will send 5–20 listing alert emails per day. Mixing them with your personal inbox is noisy. A dedicated address makes the agent's IMAP query trivial and keeps your personal Gmail clean.

## Step 1. Create the inbox

1. Open a private/incognito browser window (so you don't conflict with your existing Gmail session).
2. Go to <https://accounts.google.com/signup>.
3. Suggested handle: **`rajul.sg.listings@gmail.com`** (or any handle you like — the agent picks it up from the `GMAIL_ADDRESS` env var).
4. Use a strong password. Save it to your password manager.
5. Add your existing **rajuljain@gmail.com** as the recovery email — speeds up account verification later.

## Step 2. Turn on 2-Step Verification

This is required before Gmail will give you an App Password.

1. Sign in to the new inbox.
2. <https://myaccount.google.com/security> → **2-Step Verification** → On.
3. Phone number is fine. Skip Google Authenticator unless you want to.

## Step 3. Generate an App Password

1. <https://myaccount.google.com/apppasswords> (only visible once 2SV is on).
2. App name: `SG Rental Agent`.
3. Google will show a 16-character password like `abcd efgh ijkl mnop`.
4. **Copy it now** — Google won't show it again. (If you lose it you can revoke and generate a new one.)

## Step 4. Enable IMAP

1. In the new inbox, **Settings → See all settings → Forwarding and POP/IMAP**.
2. **IMAP access → Enable IMAP**. Save.

## Step 5. Put the secrets where the agent will read them

Create `~/.sg-rental-agent/.env`:

```bash
mkdir -p ~/.sg-rental-agent
chmod 700 ~/.sg-rental-agent
cat > ~/.sg-rental-agent/.env <<'EOF'
ANTHROPIC_API_KEY=sk-ant-...your-key...
GMAIL_ADDRESS=rajul.sg.listings@gmail.com
GMAIL_APP_PASSWORD=abcdefghijklmnop
TO_RAJUL=rajuljain@gmail.com
TO_POONAM=poonam@example.com
OUTPUT_ROOT=/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude
STATE_DB=/Users/rajuljain/.sg-rental-agent/state.db
CONFIG_DIR=/Users/rajuljain/Desktop/Rajul/Housing/House search for Aug 2026/Claude/2026-05-17/sg-rental-agent/config
EOF
chmod 600 ~/.sg-rental-agent/.env
```

Replace:
- `sk-ant-…` with your Anthropic API key from <https://console.anthropic.com/settings/keys>.
- `abcdefghijklmnop` with the 16-char App Password from Step 3 (spaces optional, agent strips them).
- `poonam@example.com` with Poonam's actual email.

## Step 6. Verify

```bash
# Load the env into the current shell
set -a; source ~/.sg-rental-agent/.env; set +a

# Test IMAP connection
python3 - <<'EOF'
import imaplib, os
m = imaplib.IMAP4_SSL("imap.gmail.com", 993)
m.login(os.environ["GMAIL_ADDRESS"], os.environ["GMAIL_APP_PASSWORD"])
m.select("INBOX")
print("IMAP OK — inbox accessible.")
m.logout()
EOF
```

If you see `IMAP OK`, you're done with Gmail setup. Move to `saved_searches_setup.md`.

## Troubleshooting

- **"Application-specific password required"** → 2SV isn't on yet, or you used the account password instead of the 16-char App Password.
- **"Invalid credentials"** → Re-check the App Password; spaces in it are fine; the *username* must be the full email address.
- **"Account access disabled"** → Google sometimes blocks new accounts after a single failed login attempt. Open <https://accounts.google.com> in the browser, sign in, dismiss any "unusual activity" warning, retry.
